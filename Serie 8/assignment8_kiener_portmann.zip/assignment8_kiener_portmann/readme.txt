Assignment 8 - Joana Portmann, Ann Kiener

1) For the second part of the exercise we had to implement 3 different tasks and that worked fairly well
also with the help of the reference to the unordered map manual.

2) We also implemented the drawing function quickly and without many problems

3) In the third part of the exercise we noticed a big 'difficulty-gap' between the first three
exercises and the last one. The problem at first was to really understand what 'T' is and that it works like
any other letter that is not 'F'. Then we also had to think about the expansion and that the 'stem' grew faster
than its leaves. 

4) For the fourth part of the exercise we had to consider symbol expansion in the stochastic case.
We had problems at first with the bat-script because it did not write any data into the 'data_out'-folder and spent
too much time searching for the bug in the code only to realize that we accidentally erased the return value.

Another difficulty was to know if we are doing the 'right' thing, since it was unclear what outputs were roughly expected.
We also did get some weird flowers growing out a line in the third one but again, maybe this was supposed to be.
We were quite happy that we always got another result, which indicated that the stochastic aspect worked.
