Assignment 9 - Joana Portmann, Ann Kiener

1) 1D Perlin Noise:
Thanks to the detailed described assignment sheet, we were able to follow it step by step and 
the implementing was really straightforward.

2) 2D Perlin Noise:
For this implementation we had to think about how to implement 2D variants of fBm and turbulence.
Here it helped that we had a detailed described picture from the lecture that explained the 2D
process very well and the differences to the 1D Perlin Noise. We did not have any problems with that.

3) Textures:
Also in this part of the exercise we did not have many difficulties, since the needed calculations for
the textures were provided.

4) Terrain:
Again this was very straightforward because the information on the assignment sheet helped a lot.
Especially the Figure 8 helped when covering each grid sqaure with two triangles, so we did could just
copy the information from the picture. 