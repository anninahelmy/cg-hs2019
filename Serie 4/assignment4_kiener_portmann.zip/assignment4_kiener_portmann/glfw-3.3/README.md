We changed an existing wave simulation to this 4d function plotter.

We started by changing the color of the simulation. 
Then we changed the code such that a static function got plotter.
Next we added the time parameter t. Up to now the function to plot needed to be hardcoded. 
Next we changed colors again. 
Next we expended the code such that the user can now input the function to plot. 

While developing the project it was hardest to manage some c specific details. Because we changed an existing project we bypassed the 
difficulties of setup a project. 