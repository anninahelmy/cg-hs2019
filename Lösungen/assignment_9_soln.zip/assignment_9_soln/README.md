Compiling
=========

This works just like for the previous projects.
The supplied scripts (*.sh for Linux & Mac, *.bat for windows) assume
`build` as build folder.

If you use another folder (Some IDEs name the build folder differently by
default), you have to adjust the scripts.

One difference: this project creates two executables, `shvi` and `terrain`.


Shader viewer (shvi) keys in interactive mode
=============================================

Mouse wheel or 8/9    Zoom
Mouse drag or WASD    Pan
P/F12/Print:          Save screenshot


Terrain viewer (terrain) keys in interactive mode
=================================================

Mouse wheel           Zoom
WASD                  Rotate



