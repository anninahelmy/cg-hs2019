#!/bin/bash
cd $(dirname $0)/..
build/shvi display_plots.frag out/perlin_1d_plot.png
