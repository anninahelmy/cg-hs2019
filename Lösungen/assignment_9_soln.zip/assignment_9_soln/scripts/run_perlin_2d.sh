#!/bin/bash
cd $(dirname $0)/..
build/shvi display_perlin.frag out/perlin_2d.png
