#!/bin/bash
cd $(dirname $0)/..
build/shvi display_turbulence.frag out/turbulence.png
