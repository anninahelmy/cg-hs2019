#!/bin/bash
cd $(dirname $0)/..
build/shvi display_fbm.frag out/fbm.png
