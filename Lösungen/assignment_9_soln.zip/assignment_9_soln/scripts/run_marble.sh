#!/bin/bash
cd $(dirname $0)/..
build/shvi display_marble.frag out/marble.png
