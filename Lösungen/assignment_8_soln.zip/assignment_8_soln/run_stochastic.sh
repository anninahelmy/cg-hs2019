#!/bin/bash
./build/lsys data_in/stochastic_00.json data_out/stochastic_00
./build/lsys data_in/stochastic_01.json data_out/stochastic_01
./build/lsys data_in/stochastic_02.json data_out/stochastic_02
