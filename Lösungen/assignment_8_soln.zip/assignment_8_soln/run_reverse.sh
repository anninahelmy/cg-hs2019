#!/bin/bash
./build/lsys reverse_in/left_plant.json reverse_out/left_plant
./build/lsys reverse_in/crossout.json reverse_out/crossout
./build/lsys reverse_in/hexerode.json reverse_out/hexerode
./build/lsys reverse_in/flower_tree.json reverse_out/flower_tree

