
#include "lsystem.h"
#include <stack>
#include <memory>
#include <iostream>

std::string LindenmayerSystemDeterministic::expandSymbol(unsigned char const& sym) {
    /*
        map.find: Iterator to an element with key equivalent to key. If no such element is found, past-the-end (see end()) iterator is returned.
        http://en.cppreference.com/w/cpp/container/unordered_map/find
    */
    auto const search = rules.find(sym);
    if(search != rules.end()) {
        // We found the rule for this symbol
        return search->second;
    } else {
        // If there is no rule for a given symbol, return the symbol unchanged
        // Converting from char to string in C++ is strange.
        // Also this example implementation is inefficient since it allocates a new string every time,
        // so for a serious solution we would cache the 1-character-strings for each symbol.
        return {char(sym)};
    }
}

std::string LindenmayerSystem::expandOnce(std::string const& symbol_sequence) {
    std::string result;

    for(char const& sym : symbol_sequence) {
        result += expandSymbol(sym);
    }

    return result;
}

std::string LindenmayerSystem::expand(std::string const& initial, uint32_t num_iters) {
    std::string state = initial;
    for(size_t idx = 0; idx < num_iters; idx++) {
        state = expandOnce(state);
    }
    return state;
}

std::vector<Segment> LindenmayerSystem::draw(std::string const& symbols) {
    std::vector<Segment> lines; // this is already initialized as empty vector
    class Pen {
        vec2 position_ = {0, 0};
        double angle_rad_ = M_PI / 2; // initial angle: up (along y axis)

    public:
        const vec2 &getPosition() const { return position_; }

        void rotate(double rot_rad) {
            angle_rad_ += rot_rad;
        }

        void step() {
            position_ += vec2(cos(angle_rad_), sin(angle_rad_));
        }
    };

    Pen current_pen;
    std::stack<Pen> saved_pen_states;
    // could also use a stack of mat3 (for homogenized 2-D coordinates)

    const double rotation_rad = deg2rad(rotation_angle_deg);

    for (auto sym : symbols) {
        switch(sym) {
            case '[': // Push (save) state, start a new branch
                saved_pen_states.push(current_pen);
            break;

            case ']': // Pop (restore) state, end branch
                current_pen = saved_pen_states.top();
                saved_pen_states.pop();
            break;

            case '+': // Rotate left
                current_pen.rotate(rotation_rad);
            break;

            case '-': // Rotate right
                current_pen.rotate(-rotation_rad);
            break;

            case 'F':
            default: // Move pen forward and draw
                vec2 old_pos = current_pen.getPosition();
                current_pen.step();
                lines.push_back(Segment(old_pos,current_pen.getPosition()));
        }
    }
    return lines;
}

std::string LindenmayerSystemStochastic::expandSymbol(unsigned char const& sym) {
    auto const search = rules.find(sym);
    if(search == rules.end()) {
        return {char(sym)};
    };

    auto const& alternatives = search->second;
    const size_t num_alternatives = alternatives.size();

    if (num_alternatives == 1) {
        // if just 1 alternative, we obviously choose it
        return alternatives[0].expansion;
    }
    /*
        We roll a value between 0 and 1 to choose the rule.
        For example, if there are 3 rules with probabilities: 0.2 0.35 0.45
        rule 1 is chosen if roll < 0.2
        rule 2 is chosen if 0.2 <= roll < 0.55
        rule 3 is chosen if 0.55 <= roll
        */
    double roll = dice.roll();
    for(StochasticRule const& sr : alternatives) {
        if( roll < sr.probability ) {
            return sr.expansion;
        } else {
            roll -= sr.probability;
        }
    }
    // This will only happen if the probabilities do not sum to 1.0
    // to keep going, we use the last rule
    return alternatives[num_alternatives-1].expansion;
}

void LindenmayerSystemDeterministic::addRuleDeterministic(unsigned char sym, std::string const& expansion) {
    rules[sym] = expansion;
}

void LindenmayerSystemStochastic::addRuleStochastic(unsigned char sym, std::vector<StochasticRule> expansions_with_ps) {
    rules[sym] = expansions_with_ps;
}
