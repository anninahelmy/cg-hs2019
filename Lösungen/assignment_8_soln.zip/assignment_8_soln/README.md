Compiling
=========

This works just like for the previous projects.
The supplied scripts (*.sh for Linux & Mac, *.bat for windows) assume
`build` as build folder.

If you use another folder (Some IDEs name the build folder differently by
default), you have to adjust the scripts.


Usage - noninteractive
======================

Supply two arguments, input file and output file prefix (no extension)

e.g.
    ./build/lsys data_in/plant_01.json data_out/plant_01
will generate data_out/plant_01.{txt,json}

Usage - interactive
===================

Supply one argument, input file:

    ./build/lsys data_in/plant_01.json


Keys in interactive mode
========================

Q/Escape              Exit
Left/right arrows     Adjust rotation angle
Up/down arrows        Adjust number of iterations
P                     Save screenshot as png

